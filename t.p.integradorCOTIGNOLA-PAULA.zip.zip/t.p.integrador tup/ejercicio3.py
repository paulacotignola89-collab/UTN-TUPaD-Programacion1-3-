# Establecemos las variables de turnos, usamos "" para indicar vacios
l1 = ""; l2 = ""; l3 = ""; l4 = ""    # Cuatro turnos disponbles para los lunes
m1 = ""; m2 = ""; m3 = ""             # Tres turnos disponibles para los martes

# Variable operador con validacion
operador = input("Nombre del operador: ")
while not operador.isalpha():
    print("Error: Solo letras.")
    operador = input("Nombre del operador: ")

opcion = ""
while opcion != "5":
    print("\n1.Reservar 2.Cancelar 3.Ver dia 4.Resumen 5.Salir")
    opcion = input("opcion: ")

    if opcion == "1":
        dia = input("Dia (1=LUNES, 2=MARTES): ")
        paciente = input("Nombre del paciente: ")

        if dia == "1":         # Verificamos que no este repetido
            if paciente == l1 or paciente == l2 or paciente == l3 or paciente == l4:
                print("Ya tiene turno.")
            elif l1 == "": l1 = paciente; print("Guardado en turno 1")
            elif l2 == "": l2 = paciente; print("Guardado en turno 2")
            elif l3 == "": l3 = paciente; print("Guardado en turno 3")
            elif l4 == "": l4 = paciente; print("Guardado en turno 4")
            else: print("Lunes lleno.")

        elif dia == "2":
            if paciente == m1 or paciente == m2 or paciente == m3:
                print("Ya tiene turno.")
            elif m1 == "": m1 = paciente; print("Guardado en turno 1")
            elif m2 == "": m2 = paciente; print("Guardado en turno 2")
            elif m3 == "": m3 = paciente; print("Guardado en turno 3")
            else: print("Martes lleno.")

    elif opcion == "2":
        nombre = input("Paciente a cancelar: ")      # Buscamos en todos los turnos coincidencia
        if l1 == nombre: l1 = ""; print("Cancelado")
        elif l2 == nombre: l2 = ""; print("Cancelado")
        elif l3 == nombre: l3 = ""; print("Cancelado")
        elif l4 == nombre: l4 = ""; print("Cancelado")
        elif m1 == nombre: m1 = ""; print("Cancelado")
        elif m2 == nombre: m2 = ""; print("Cancelado")
        elif m3 == nombre: m3 = ""; print("Cancelado")
        else: print("No se encontró.")

    elif opcion == "3":
        dia = input("¿Que dia ver? (1/2): ")
        if dia == "1":
            print("1:", l1 if l1 != "" else "(libre)")
            print("2:", l2 if l2 != "" else "(libre)")
            print("3:", l3 if l3 != "" else "(libre)")
            print("4:", l4 if l4 != "" else "(libre)")
        elif dia == "2":
            print("1:", m1 if m1 != "" else "(libre)")
            print("2:", m2 if m2 != "" else "(libre)")
            print("3:", m3 if m3 != "" else "(libre)")

    elif opcion == "4":         # Contar ocupados 
        ocupados_l = 0
        if l1 != "": ocupados_l += 1
        if l2 != "": ocupados_l += 1
        if l3 != "": ocupados_l += 1
        if l4 != "": ocupados_l += 1

        ocupados_m = 0
        if m1 != "": ocupados_m += 1
        if m2 != "": ocupados_m += 1
        if m3 != "": ocupados_m += 1

        print(f"lunes: {ocupados_l} ocupados, {4-ocupados_l} libres.")
        print(f"martes: {ocupados_m} ocupados, {3-ocupados_m} libres.")

        if ocupados_l > ocupados_m:
            print("El lunes tiene mas turnos.")
        elif ocupados_m > ocupados_l:
            print("El martes tiene mas turnos.")
        else:
            print("Hay un empate.")

print("Sistema cerrado.")



