# pedimos el nombre del cliente, teniendo en cuenta que solo puede contener letras y no estar vacio.
nombre = input("Cliente: ")
# validamos que solo tenga letras y no este vacio
while not nombre.isalpha() or nombre == "":
    print("Error, el nombre debe contener solo letras y no puede estar vacio.")
    nombre = input("Cliente: ")

# pedimos cantidad de productos teniendo en cuenta las validaciones solicitadas
cantidad_str = input("Cantidad de productos: ")
#validamos que solo sean numeros y positivos
while not cantidad_str.isdigit() or int(cantidad_str) <= 0:
    print("Error: debe ingresar un numero entero mayor a cero.")
    cantidad_str = input("Cantidad de productos: ")

cantidad = int(cantidad_str)

# inicializo con los acumuladores.
total_sin_descuentos = 0
total_con_descuentos = 0

for i in range(1, cantidad+1):
    precio_str = input (f"Producto {i} - Precio: ")
    #validamos el precio
    while not precio_str.isdigit():
        print("Error: El precio debe ser un numero entero.")
        precio_str = input(f"Ingrese el precio del producto {i} nuevamente: ")

    precio = int(precio_str)

# validamos si tiene descuento y usamos .lower
    tiene_descuento = input("¿Tiene descuento?: (S/N): ").lower()
    while tiene_descuento not in ['s', 'n']:
        print("Error: Solo se permite ingresar 'S' para Si o 'N' para No." )
        tiene_descuento = input("¿Tiene descuento? (S/N): ").lower()

# si tiene descuento aplicamos el 10% de descuento
    precio_con_descuento = precio
    if tiene_descuento == 's':
       precio_con_descuento = precio * 0.90

#acumulamos los totales
    total_sin_descuentos += precio
    total_con_descuentos += precio_con_descuento

# calculamos valores restantes
ahorro_total = total_sin_descuentos - total_con_descuentos
promedio = float(total_con_descuentos / cantidad)

#mostramos los resultados
print("\n========================RESUMEN DE COMPRA========================")
print(f"Total sin descuentos: ${total_sin_descuentos}")
print(f"Total con descuentos: ${total_con_descuentos: .2f}") # usamos .2f para mostrar dos decimales
print(f"Ahorro total: ${ahorro_total: .2f}")
print(f"promedio por producto: ${promedio: .2f}") 