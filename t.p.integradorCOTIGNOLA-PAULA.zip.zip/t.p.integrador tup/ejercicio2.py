# Definimos credenciales
usuario_correcto = "alumno"
clave_correcta = "python123"

# Establecemos variables
intentos = 0
acceso_concedido = False

#comenzamos el login con intentos limitados
while intentos < 3:
    intentos += 1
    print(f"\nIntento {intentos}/3")
    usuario_ingresado = input("Usuario: ")
    clave_ingresada = input("Clave: ")

    if usuario_ingresado == usuario_correcto and clave_ingresada == clave_correcta:
        print("Acceso concedido.")
        acceso_concedido = True
        break
    else:
        print("Error: credenciales inválidas.")

#si los 3 intentos son fallidos
if not acceso_concedido:
    print("\nCuenta bloqueada")
else:
    opcion = ""                 # menu repetitivo
    while opcion != "4":
        print("\n--- MENÚ---")
        print("1) Ver estado de inscripcion")
        print("2) Cambiar clave")
        print("3) Mensaje motivacional")
        print("4) Salir")

        opcion = input("Opcion: ")

        if not opcion.isdigit():           # validacion
            print("ERROR: infrese un numero válido.")
        elif int(opcion) < 1 or int(opcion) > 4:
            print("Opción fuera de rango.")
        else:
            if opcion == "1":
                print("Estado: INSCRIPTO")
            elif opcion == "2":
                nueva_clave = input("Nueva clave (mínimo 6 caracteres): ")
                if len(nueva_clave)<6:           # validacion de longitud
                    print("Error: mínimo 6 caracteres.")
                else:
                    confirmacion = input("Confirme su nueva clave: ")
                    if nueva_clave == confirmacion:
                        clave_correcta = nueva_clave
                        print("Clave cambiada con exito.")
                    else:
                        print("Error: las claves no coinciden.")
            elif opcion == "3":
                print ("¡Tu esfuerzo vale la pena!")
            elif opcion == "4":
                print("Saliendo del sistema.")