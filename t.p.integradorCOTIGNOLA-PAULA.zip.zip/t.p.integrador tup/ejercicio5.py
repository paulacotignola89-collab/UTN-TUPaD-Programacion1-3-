 # iniciamos con la configuracion pidiendo nombre y validacion
nombre = input("Ingrese el nombre de su Gladiador: ")
while not nombre.isalpha() or nombre == "":
    print("Error: Solo se permiten letras.")
    nombre = input("Ingrese el nombre de su Gladiador: ")

# inicializacion de estadisticas
hp_gladiador = 100
hp_enemigo = 100
pociones = 3
ataque_pesado_base = 15
daño_enemigo = 12
juego_activo = True           # variable booleana

print(f"\n--- BIENVENIDO A LA ARENA, {nombre.upper()}---")

# Ciclo de combate
while hp_gladiador > 0 and hp_enemigo > 0:   # El juego continua mientras ambos esten vivos
    print(f"\n{nombre} (HP: {hp_gladiador}) vs Enemigo (HP: {hp_enemigo} | Pociones: {pociones})")
    print("1. Ataque pesado")
    print("2. Ráfaga veloz")
    print("3. Curar")

    # menu y validacion
    opcion = input("Elija una accion (1-3): ")
    while not opcion.isdigit or not (1 <= int(opcion) <= 3):
        print("Error: ingrese un numero validos entre 1 y 3.")
        opcion = input("Elija una accion (1-3): ")

    opcion = int(opcion)

# Logica de acciones
    if opcion == 1:       # Accion A: ataque pesado
        daño_final = float(ataque_pesado_base)
        if hp_enemigo < 20:
            daño_final = ataque_pesado_base * 1.5   # Golpe critico
            print("GOLPE CRÍTICO!")

        hp_enemigo -= int(daño_final)
        print(f"¡Atacaste al enemigo por {daño_final} puntos de daño!")

    elif opcion == 2:   # Aciion B: rafaga veloz
        print(">> ¡Inicias una ráfaga de golpes!")
        for i in range(3):
            hp_enemigo -= 5
            print(" > Golpe conectado por 5 de daño")

    elif opcion == 3:
        if pociones > 0:
            hp_gladiador += 30
            pociones -= 1
            print(f"Te has curado. Vida actual: {hp_gladiador}")
        else:
            print("¡No quedan pociones! Pierdes el turno intentando buscar una.")

    # Turno del enemigo que ataca solo si sigue vivo despues de la accion del jugador
    if hp_enemigo > 0:
        hp_gladiador -= daño_enemigo
        print(f"¡El enemigo te atacó por {daño_enemigo} puntos de daño!")

    # Fin del juego
if hp_gladiador > 0:
    print(f"\n¡VICTORIA! {nombre} ha ganado la batalla.")
else:
    print("\nDERROTA. Has caido en combate.")
