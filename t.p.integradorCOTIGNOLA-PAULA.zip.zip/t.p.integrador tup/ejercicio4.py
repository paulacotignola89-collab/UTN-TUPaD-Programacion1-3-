# establecemos las variables indicadas en la consigna
energia = 100
tiempo = 12
cerraduras_abiertas = 0
alarma = False
codigo_parcial = ""
forzar_seguidos = 0   # contador para la regla anti-spam

# solicitamos y validamos nombre del agente
nombre_agente = input("Ingrese su nombre de agente: ")
while not nombre_agente.isalpha():
    print("Error: el nombre debe contener solo letras.")
    nombre_agente = input("Ingrese su nombre de agente: ")

print(f"\n--- BIENVENIDO AGENTE {nombre_agente.upper()} A LA BOVEDA---")

# ciclo del juego
while energia > 0 and tiempo > 0 and cerraduras_abiertas < 3:

    # Establecemos regla de bloqueo por alarma
    if alarma == True and tiempo <= 3:
        break

    # Se muestra estado
    print(f"\nESTADO: Energia: {energia} | Tiempo: {tiempo} | Cerraduras: {cerraduras_abiertas}")
    if alarma:
        print("¡ALERTA: ALARMA ACTIVADA!")

    # Establecemos el menu de acciones
    print("1. Forzar cerradura (-20 energia, -2 tiempo)")
    print("2. Hackear panel (-10 energia, -3 tiempo)")
    print("3. Descansar (+15 energia, -1 tiempo)")

    opcion = input("Elija una accion (1-3): ")
    while not opcion.isdigit() or not (1 <= int(opcion) <= 3):
        print("Error: Ingrese una opcion valida (1, 2 o 3).")
        opcion = input ("Elija una accion (1-3): ")

    opcion = int(opcion)

    # Logica de las acciones
    if opcion == 1:     # Costos fijos
        energia -= 20
        tiempo -= 2
        forzar_seguidos += 1

        # Regla anti-spam: recera vez seguida activa alarma y no abre
        if forzar_seguidos == 3:
            print("¡La cerradura se trabó por forzar repetidas veces! Alarma activada.")
            alarma = True
        else:                # Informamos riesgo de alarma si la energía es baja.
            if energia < 40:
                print("ENERGIA BAJA (RIESGO DE ALARMA)")
                riesgo = input("Elija un numero del 1 a 3: ")
                while not riesgo.isdigit() or not (1 <= int(riesgo) <= 3):
                    riesgo = input("Elija un numero del 1 al 3: ")
                if int(riesgo) == 3: alarma = True
                print("¡Accion fallida! Se activo la alarma.")
            if not alarma:
                cerraduras_abiertas += 1              # Si no hay alarma, la cerradura se abre
                print("¡Cerradura abierta con exito!")
    elif opcion == 2:
        forzar_seguidos = 0
        energia -= 10
        tiempo -= 3

        print("Hackeando")
        for i in range (4):
            print(f"Progreso: {(i+1)*25}%")
            codigo_parcial += "A"

        if len(codigo_parcial) >= 8:
            if cerraduras_abiertas < 3:
                cerraduras_abiertas += 1
                print("¡Codigo completado! Se abrio una cerradura automaticamente.")  # Se reinicia el codigo para que continue si faltan cerraduras
            codigo_parcial = ""

    elif opcion == 3:           # Descansar
        forzar_seguidos = 0     
        tiempo -= 1
        descanso = 15
        if alarma:
            descanso -= 10 

        energia += descanso
        if energia > 100:
            energia = 100
            print(f"Has descansado. Energia actual: {energia}")

# Condiciones de fin del juego
if cerraduras_abiertas == 3:
    print(f"\n¡Victoria! El agente {nombre_agente} ha abierto la bóveda.")
elif energia <= 0 or tiempo <= 0:
    print("\nDerrota: te has quedado sin recursos (energia o tiempo).")
elif alarma == True and tiempo <= 3:
    print("\nDerrota: el sistema se bloqueó por la alarma y el tiempo agotado.")
